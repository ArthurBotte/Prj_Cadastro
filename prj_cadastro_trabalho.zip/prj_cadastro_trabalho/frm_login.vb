﻿
Public Class frm_login
    Private Sub frm_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            ' Conectar ao banco de dados
            conecta_banco_access()
            txt_nome.Focus()
            txt_nome.Clear()
            txt_senha.Clear()
        Catch ex As Exception
            MsgBox("Erro ao conectar ao banco de dados: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ERRO")
        End Try
    End Sub

    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        Try
            ' Cobrar campos vazios
            If String.IsNullOrWhiteSpace(txt_nome.Text) Then
                MsgBox("Informe o nome!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")
                txt_nome.Focus()
                Exit Sub
            End If

            If String.IsNullOrWhiteSpace(txt_senha.Text) Then
                MsgBox("Informe a senha!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")
                txt_senha.Focus()
                Exit Sub
            End If

            ' Login de administrador 
            If txt_nome.Text.ToLower() = "admin" AndAlso txt_senha.Text.ToLower() = "admin" Then
                MsgBox("Login de Administrador realizado com sucesso!",
                        MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ACESSO ADMIN")
                Me.Hide()
                frm_cadastro.Show()
                txt_nome.Clear()
                txt_senha.Clear()
                Exit Sub
            End If

            ' Consultar usuário no banco de dados
            sql = $"SELECT * FROM tb_clientes WHERE nome='{txt_nome.Text}'"
            rs = db.Execute(sql)

            If rs.EOF = False Then
                ' Verificar senha
                If rs.Fields("senha").Value.ToString() <> txt_senha.Text Then
                    MsgBox("Nome ou senha incorretos!",
                           MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ERRO DE LOGIN")
                    txt_senha.Clear()
                    txt_senha.Focus()
                    Exit Sub
                End If

                ' Verificar se a conta está ativa (não bloqueada)
                Dim contaAtiva As Boolean = True

                Try
                    If Not IsDBNull(rs.Fields("ativo").Value) Then
                        contaAtiva = (rs.Fields("ativo").Value = 1)
                    End If
                Catch
                    ' Se o campo não existir ou houver erro, considera a conta como ativa
                    contaAtiva = True
                End Try

                If Not contaAtiva Then
                    ' Conta está bloqueada
                    MsgBox("Esta conta está bloqueada!" & vbCrLf & "Entre em contato com o administrador.",
                           MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "CONTA BLOQUEADA")
                    txt_senha.Clear()
                    txt_senha.Focus()
                    Exit Sub
                End If
                MsgBox("Login realizado com sucesso!" & vbCrLf & "Bem-vindo(a), " & rs.Fields("nome").Value & "!",
                       MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SUCESSO")
                ' Abrir o Form1 para usuários normais
                Me.Hide()
                Form1.Show()
                txt_nome.Clear()
                txt_senha.Clear()
            Else
                ' Nome não encontrado
                MsgBox("Nome ou senha incorretos!",
                       MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ERRO DE LOGIN")
                txt_senha.Clear()
                txt_senha.Focus()
            End If

        Catch ex As Exception
            MsgBox("Erro ao processar login: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ERRO")
        End Try
    End Sub




End Class