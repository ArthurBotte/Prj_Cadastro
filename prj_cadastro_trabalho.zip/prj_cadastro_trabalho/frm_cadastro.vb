﻿Public Class frm_cadastro
    Private Sub img_foto_Click(sender As Object, e As EventArgs) Handles img_foto.Click
        Try
            With OpenFileDialog1
                .Title = "Selecione uma Foto"
                .InitialDirectory = Application.StartupPath & "\Fotos\"
                .ShowDialog()
                diretorio = .FileName
                ' diretorio = diretorio.Replace("\", "/")
                img_foto.Load(diretorio)
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub frm_cadastro_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_banco_access()
        carregar_dados()
        carregar_tipo_dados()
    End Sub

    Private Sub btn_gravar_Click(sender As Object, e As EventArgs) Handles btn_gravar.Click
        Try
            If txt_senha.Text <> txt_confsenha.Text Then
                MsgBox("As senhas não coincidem!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")
                txt_senha.Focus()
                Exit Sub
            End If

            If String.IsNullOrWhiteSpace(txt_senha.Text) Then
                MsgBox("A senha não pode estar vazia!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")
                txt_senha.Focus()
                Exit Sub
            End If

            Dim statusConta As Integer = 1

            sql = $"select * from tb_clientes where cpf='{txt_cpf.Text}'"
            rs = db.Execute(sql)
            If rs.EOF = False Then 'Se existir o cpf na tabela
                sql = $"update tb_clientes set nome='{txt_nome.Text}',
                                            data_nasc='{cmb_data_nasc.Value.ToShortDateString}',
                                           fone='{txt_fone.Text}',
                                           email='{txt_email.Text}',
                                           foto='{diretorio}',
                                           senha='{txt_senha.Text}',
                                           ativo={statusConta} where cpf='{txt_cpf.Text}'"
                rs = db.Execute(UCase(sql))
                MsgBox("Dados alterados com sucesso!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")
            Else
                sql = $"insert into tb_clientes (cpf,nome,data_nasc,fone,email,foto,senha,ativo) values
                       ('{txt_cpf.Text}', '{txt_nome.Text}', '{cmb_data_nasc.Value.ToShortDateString}',
                        '{txt_fone.Text}','{txt_email.Text}','{diretorio}','{txt_senha.Text}',{statusConta})"
                rs = db.Execute(UCase(sql))
                MsgBox("Dados gravados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")

            End If
            carregar_dados()
            txt_cpf.Clear()
            txt_nome.Clear()
            cmb_data_nasc.Value = Now
            txt_fone.Clear()
            txt_email.Clear()
            txt_senha.Clear()
            txt_confsenha.Clear()
            img_foto.Load(Application.StartupPath & "\Fotos\nova_foto.png")
            txt_cpf.Focus()

        Catch ex As Exception
            MsgBox("Erro ao gravar: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")

        End Try
    End Sub

    Private Sub txt_cpf_LostFocus(sender As Object, e As EventArgs) Handles txt_cpf.LostFocus
        Try
            sql = $"select * from tb_clientes where cpf='{txt_cpf.Text}'"
            rs = db.Execute(sql)
            If rs.EOF = False Then 'Se existir o cpf na tabela
                txt_nome.Text = rs.Fields(2).Value
                cmb_data_nasc.Value = rs.Fields(3).Value
                txt_fone.Text = rs.Fields(4).Value
                txt_email.Text = rs.Fields(5).Value
                img_foto.Load(rs.Fields(6).Value)

                ' Tentar carregar senha se existir
                Try
                    txt_senha.Text = rs.Fields(7).Value
                    txt_confsenha.Text = rs.Fields(7).Value
                Catch
                    ' Se não existir o campo senha, ignora
                    txt_senha.Text = ""
                    txt_confsenha.Text = ""
                End Try
            Else
                txt_nome.Focus()
            End If
        Catch ex As Exception
            MsgBox("Erro ao consultar!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Private Sub txt_cpf_DoubleClick(sender As Object, e As EventArgs) Handles txt_cpf.DoubleClick
        txt_cpf.Clear()
        txt_nome.Clear()
        cmb_data_nasc.Value = Now
        txt_fone.Clear()
        txt_email.Clear()
        txt_senha.Clear()
        txt_confsenha.Clear()
        img_foto.Load(Application.StartupPath & "\Fotos\nova_foto.png")
        txt_cpf.Focus()
    End Sub

    Private Sub carregar_dados()
        Try
            With dgv_dados
                sql = "SELECT * FROM tb_clientes ORDER BY nome"
                rs = db.Execute(sql)
                cont = 1
                .Rows.Clear()

                Do While rs.EOF = False
                    ' Verifica o status da conta
                    Dim ativo As Boolean = True
                    Dim textoStatus As String = "ATIVO"

                    Try
                        If Not IsDBNull(rs.Fields(8).Value) Then
                            ativo = (rs.Fields(8).Value = 1)
                            If ativo Then
                                textoStatus = "ATIVO"
                            Else
                                textoStatus = "BLOQUEADO"
                            End If
                        End If
                    Catch
                        ativo = True
                        textoStatus = "ATIVO"
                    End Try

                    ' Adiciona a linha: Nº, CPF, NOME, EDITAR, EXCLUIR, ATIVAR/BLOQUEAR (6 colunas)
                    .Rows.Add(cont, rs.Fields(1).Value, rs.Fields(2).Value, Nothing, Nothing, textoStatus)

                    ' Define a cor da célula baseada no status
                    If ativo Then
                        .Rows(cont - 1).Cells(5).Style.BackColor = Color.LightGreen
                        .Rows(cont - 1).Cells(5).Style.ForeColor = Color.DarkGreen
                        .Rows(cont - 1).Cells(5).Style.Font = New Font(dgv_dados.Font, FontStyle.Bold)
                    Else
                        .Rows(cont - 1).Cells(5).Style.BackColor = Color.LightCoral
                        .Rows(cont - 1).Cells(5).Style.ForeColor = Color.DarkRed
                        .Rows(cont - 1).Cells(5).Style.Font = New Font(dgv_dados.Font, FontStyle.Bold)
                    End If

                    rs.MoveNext()
                    cont = cont + 1
                Loop
            End With
        Catch ex As Exception
            MsgBox("Erro ao carregar dados: " & ex.Message, MsgBoxStyle.Critical, "ERRO")
        End Try
    End Sub

    Private Sub txt_buscar_TextChanged(sender As Object, e As EventArgs) Handles txt_buscar.TextChanged
        With dgv_dados
            sql = $"select * from tb_clientes where {cmb_campo.Text} like '{txt_buscar.Text}%'"
            rs = db.Execute(sql)
            cont = 1
            .Rows.Clear()

            Do While rs.EOF = False
                ' Verifica o status da conta
                Dim ativo As Boolean = True
                Dim textoStatus As String = "ATIVO"

                Try
                    If Not IsDBNull(rs.Fields(8).Value) Then
                        ativo = (rs.Fields(8).Value = 1)
                        If ativo Then
                            textoStatus = "ATIVO"
                        Else
                            textoStatus = "BLOQUEADO"
                        End If
                    End If
                Catch
                    ativo = True
                    textoStatus = "ATIVO"
                End Try

                .Rows.Add(cont, rs.Fields(1).Value, rs.Fields(2).Value, Nothing, Nothing, textoStatus)

                ' Define a cor da célula
                If ativo Then
                    .Rows(cont - 1).Cells(5).Style.BackColor = Color.LightGreen
                    .Rows(cont - 1).Cells(5).Style.ForeColor = Color.DarkGreen
                    .Rows(cont - 1).Cells(5).Style.Font = New Font(dgv_dados.Font, FontStyle.Bold)
                Else
                    .Rows(cont - 1).Cells(5).Style.BackColor = Color.LightCoral
                    .Rows(cont - 1).Cells(5).Style.ForeColor = Color.DarkRed
                    .Rows(cont - 1).Cells(5).Style.Font = New Font(dgv_dados.Font, FontStyle.Bold)
                End If

                rs.MoveNext()
                cont = cont + 1
            Loop
        End With
    End Sub

    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick
        Try
            With dgv_dados
                ' EDITAR - coluna 3
                If .CurrentRow.Cells(3).Selected = True Then
                    aux_cpf = .CurrentRow.Cells(1).Value
                    sql = $"SELECT * FROM tb_clientes WHERE cpf ='{aux_cpf}'"
                    rs = db.Execute(sql)

                    txt_cpf.Text = rs.Fields(1).Value
                    txt_nome.Text = rs.Fields(2).Value
                    cmb_data_nasc.Value = rs.Fields(3).Value
                    txt_fone.Text = rs.Fields(4).Value
                    txt_email.Text = rs.Fields(5).Value

                    ' Tentar carregar a imagem
                    Try
                        Dim caminhoImagem As String = rs.Fields(6).Value
                        If Not String.IsNullOrEmpty(caminhoImagem) AndAlso System.IO.File.Exists(caminhoImagem) Then
                            img_foto.Load(caminhoImagem)
                        Else
                            img_foto.Image = Nothing ' Limpa a imagem se não existir
                        End If
                    Catch
                        img_foto.Image = Nothing ' Se der erro, limpa a imagem
                    End Try

                    ' Tentar carregar senha se existir
                    Try
                        txt_senha.Text = rs.Fields(7).Value
                        txt_confsenha.Text = rs.Fields(7).Value
                    Catch
                        txt_senha.Text = ""
                        txt_confsenha.Text = ""
                    End Try

                    ' EXCLUIR - coluna 4
                ElseIf .CurrentRow.Cells(4).Selected = True Then
                    aux_cpf = .CurrentRow.Cells(1).Value
                    resp = MsgBox("Deseja realmente Excluir?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                    If resp = MsgBoxResult.Yes Then
                        sql = $"DELETE FROM tb_clientes WHERE cpf='{aux_cpf}'"
                        rs = db.Execute(sql)
                        carregar_dados()
                    End If

                    ' ATIVAR/BLOQUEAR - coluna 5
                ElseIf .CurrentRow.Cells(5).Selected = True Then
                    aux_cpf = .CurrentRow.Cells(1).Value
                    Dim nome As String = .CurrentRow.Cells(2).Value.ToString()
                    Dim textoAtual As String = .CurrentRow.Cells(5).Value.ToString()

                    ' Determina o status atual baseado no texto
                    Dim statusAtual As Boolean = (textoAtual = "ATIVO")
                    Dim novoStatus As Boolean = Not statusAtual

                    ' Mensagem de confirmação
                    Dim mensagem As String
                    If novoStatus Then
                        mensagem = $"Deseja ATIVAR a conta de {nome}?" & vbCrLf & vbCrLf &
                              "O usuário poderá fazer login no sistema."
                    Else
                        mensagem = $"Deseja BLOQUEAR a conta de {nome}?" & vbCrLf & vbCrLf &
                              "O usuário não poderá mais fazer login no sistema."
                    End If

                    resp = MsgBox(mensagem, MsgBoxStyle.Question + MsgBoxStyle.YesNo, "CONFIRMAR ALTERAÇÃO")

                    If resp = MsgBoxResult.Yes Then
                        Dim statusDB As Integer = If(novoStatus, 1, 0)
                        sql = $"UPDATE tb_clientes SET ativo={statusDB} WHERE cpf='{aux_cpf}'"
                        db.Execute(sql)

                        If novoStatus Then
                            .CurrentRow.Cells(5).Value = "ATIVO"
                            .CurrentRow.Cells(5).Style.BackColor = Color.LightGreen
                            .CurrentRow.Cells(5).Style.ForeColor = Color.DarkGreen
                        Else
                            .CurrentRow.Cells(5).Value = "BLOQUEADO"
                            .CurrentRow.Cells(5).Style.BackColor = Color.LightCoral
                            .CurrentRow.Cells(5).Style.ForeColor = Color.DarkRed
                        End If

                        If novoStatus Then
                            MsgBox("Conta ativada com sucesso!", MsgBoxStyle.Information, "SUCESSO")
                        Else
                            MsgBox("Conta bloqueada com sucesso!", MsgBoxStyle.Information, "SUCESSO")
                        End If
                    End If
                Else
                    Exit Sub
                End If
            End With
        Catch ex As Exception
            MsgBox("Erro: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub
End Class